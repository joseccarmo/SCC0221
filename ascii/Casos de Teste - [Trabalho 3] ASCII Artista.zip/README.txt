Arquivo zip gerado em: 30/07/2021 19:26:13 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Trabalho 3] ASCII Artista